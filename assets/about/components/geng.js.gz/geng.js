function Geng(){
    return(
        <div className="geng-main">
            <div className="geng-detail">
                
            </div>
            <div className="geng-video">

            </div>
        </div>
    );
};

const geng_play = ReactDOM.createRoot(document.getElementById('geng-box'));
geng_play.render(<Geng />);