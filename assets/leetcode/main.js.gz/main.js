import { CopyBlock } from 'https://cdn.jsdelivr.net/npm/react-code-blocks@0.1.6/+esm'


const leet_boxs = ReactDOM.createRoot(document.getElementById('leetcode'));
leet_boxs.render(<Leetcode />);ß