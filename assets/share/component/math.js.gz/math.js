import * as mandelbrotSet from 'https://esm.run/mandelbrot-set';



console.log(mandelbrotSet);