window.poll = {
    type: 4,
    "POLL01": {
        img: "https://rainsin-1305486451.file.myqcloud.com/rainsin-blog/img/cube/4/poll/svgexport-2.svg",
        data: [
            {
                name: "POLL01",
                alg:"Rw U2 x Rw U2 Rw U2 Rw' U2 Lw U2 Rw' U2 Rw U2 Rw' U2 Rw'"
            },
            {
                name: "POLL01",
                alg:"Rw' U2' Rw U2 Rw U2' Rw2' F2 Rw' U2 Rw' U2' F2 Rw2 F2"
            },
            {
                name: "POLL01",
                alg:"Rw2 B2 U2 Lw U2 Rw' U2 Rw U2 F2 Rw F2 Lw' B2 Rw2"
            },
            {
                name: "POLL01",
                alg:"Rw2 B2 Rw' U2 Rw' U2 x' U2 Rw' U2 Rw U2 Rw' U2 Rw2 U2 x"
            },
        ]
    },
    "POLL02": {
        img: "https://rainsin-1305486451.file.myqcloud.com/rainsin-blog/img/cube/4/poll/svgexport-5.svg",
        data: [
            {
                name: "POLL02",
                alg:"y2 F R U R' U' F' U Rw U2 x Rw U2 Rw U2 Rw' U2 Lw U2 Rw' U2 Rw U2 Rw' U2 Rw'"
            },
            {
                name: "POLL02",
                alg:"2R' U2 2L F2 2L' F2 2R2 U2 2R U2 2R' U2 F2 2R2 F2"
            },
            {
                name: "POLL02",
                alg:"R U2 R' U' Rw U2 x Rw U2 Rw U2 Rw' U2 Lw U2 Rw' U2 Rw U2 Rw' U2 Rw' F R' F' R"
            },
            {
                name: "POLL02",
                alg:"R' Rw2 B2 Rw' U2 Rw' U2 x' U2 Rw' U2 Rw U2 Rw' U2 Rw2 U2 x U2 R R R R R"
            },
        ]
    },
    "POLL03": {
        img: "https://rainsin-1305486451.file.myqcloud.com/rainsin-blog/img/cube/4/poll/svgexport-6.svg",
        data: [
            {
                name: "POLL03",
                alg:"M Rw U2 x Rw U2 Rw U2 Rw' U2 Lw U2 Rw' U2 Rw U2 Rw' U2 Rw' M'"
            },
            {
                name: "POLL03",
                alg:"M Rw2 B2 U2 Lw U2 Rw' U2 Rw U2 F2 Rw F2 Lw' B2 Rw2 M'"
            },
            {
                name: "POLL03",
                alg:"M Rw' U2' Rw U2 Rw U2' Rw2' F2 Rw' U2 Rw' U2' F2 Rw2 F2 M'"
            },
            {
                name: "POLL03",
                alg:"y2 2R2 U2 2R2 Uw2 2R2 Uw2 Rw U2 x Rw U2 Rw U2 Rw' U2 Lw U2 Rw' U2 Rw U2 Rw' U2 Rw'"
            },
        ]
    },
}